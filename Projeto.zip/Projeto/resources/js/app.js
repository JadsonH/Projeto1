import * as cep from './scripts.js';
import * as cep from './progressbar.min.js';